import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IngestionTwoComponent } from './ingestion-two.component';

describe('IngestionTwoComponent', () => {
  let component: IngestionTwoComponent;
  let fixture: ComponentFixture<IngestionTwoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IngestionTwoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IngestionTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
