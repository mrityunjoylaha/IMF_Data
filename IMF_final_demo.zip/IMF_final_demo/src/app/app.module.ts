import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes} from '@angular/router';
import { SafePipeModule } from 'safe-pipe';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { ApplicationsComponent } from './applications/applications.component';
import { SignupComponent } from './signup/signup.component';
import {AuthenticationService, TokenPayload } from './authentication.service';
import {AuthGuardService} from './auth-guard.service';
import { IframeComponent } from './iframe/iframe.component';
import { HeaderComponent } from './header/header.component';
import { DemoComponent } from './demo/demo.component';
import { Demo1Component } from './demo1/demo1.component';
import { SubmitComponent } from './submit/submit.component';
import { ApplicationOneComponent } from './application-one/application-one.component';
import { Demo2Component } from './demo2/demo2.component';
import { GraphComponent } from './graph/graph.component';
import { WorkflowComponent } from './workflow/workflow.component';
import { MetadataComponent } from './metadata/metadata.component';
import { MetadataTwoComponent } from './metadata-two/metadata-two.component';
import { IngestionTwoComponent } from './ingestion-two/ingestion-two.component';
import { IngestionThreeComponent } from './ingestion-three/ingestion-three.component';
import { IngestionFourComponent } from './ingestion-four/ingestion-four.component';
import { IngestionFiveComponent } from './ingestion-five/ingestion-five.component';
import { IngestionSixComponent } from './ingestion-six/ingestion-six.component';
import { ApprovegraphComponent } from './approvegraph/approvegraph.component';
import { RejectgraphComponent } from './rejectgraph/rejectgraph.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    WelcomeComponent,
    ApplicationsComponent,
    SignupComponent,
    IframeComponent,
    HeaderComponent,
    DemoComponent,
    Demo1Component,
    SubmitComponent,
    ApplicationOneComponent,
    Demo2Component,
    GraphComponent,
    WorkflowComponent,
    MetadataComponent,
    MetadataTwoComponent,
    IngestionTwoComponent,
    IngestionThreeComponent,
    IngestionFourComponent,
    IngestionFiveComponent,
    IngestionSixComponent,
    ApprovegraphComponent,
    RejectgraphComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    SafePipeModule
  ],
  providers: [AuthenticationService,AuthGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
