import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approvegraph',
  templateUrl: './approvegraph.component.html',
  styleUrls: ['./approvegraph.component.css']
})
export class ApprovegraphComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
