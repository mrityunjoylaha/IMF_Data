import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService, UserDetails } from '../authentication.service';

@Component({
  selector: 'app-ingestion-four',
  templateUrl: './ingestion-four.component.html',
  styleUrls: ['./ingestion-four.component.css']
})
export class IngestionFourComponent implements OnInit {

  details:UserDetails

  constructor(public auth: AuthenticationService,private router : Router) { }

  ngOnInit(): void {

    this.auth.profile().subscribe(
      user => {
          this.details =user
      }
  
  )

}
}
