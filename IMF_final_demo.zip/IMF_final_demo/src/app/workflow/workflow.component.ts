import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {AuthenticationService, UserDetails} from '../authentication.service'
import { HttpBackend } from '@angular/common/http';

@Component({
  selector: 'app-workflow',
  templateUrl: './workflow.component.html',
  styleUrls: ['./workflow.component.css']
})
export class WorkflowComponent {
  details:UserDetails
  constructor(public auth: AuthenticationService,private router : Router){}

 
  
 

  //   if(localStorage.getItem("usertoken") == null){
  //     alert('Please login First')
   
  // }

    // this.auth.profile().subscribe(
    //     user => {
    //         this.details =user
    //     },
    //     err => {
    //         console.error(err)
    //     }

    // )

    back(): void {

    this.auth.profile().subscribe(
      user => {
          this.details =user
          if(user.role == 'Approver'){
          
              this.router.navigate(['/applicationOne']);
            
          }


          if(user.role == 'User')
          {
              
              this.router.navigate(['/applications']);
        
            }
      
            })
          }
        }
      


