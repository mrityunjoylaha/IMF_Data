import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MetadataTwoComponent } from './metadata-two.component';

describe('MetadataTwoComponent', () => {
  let component: MetadataTwoComponent;
  let fixture: ComponentFixture<MetadataTwoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetadataTwoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetadataTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
