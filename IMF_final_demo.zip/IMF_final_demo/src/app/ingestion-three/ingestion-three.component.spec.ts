import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IngestionThreeComponent } from './ingestion-three.component';

describe('IngestionThreeComponent', () => {
  let component: IngestionThreeComponent;
  let fixture: ComponentFixture<IngestionThreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IngestionThreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IngestionThreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
