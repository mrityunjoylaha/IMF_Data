import { Component, OnInit } from '@angular/core';
import {AuthenticationService, UserDetails} from '../authentication.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-applications',
  templateUrl: './applications.component.html',
  styleUrls: ['./applications.component.css']
})
export class ApplicationsComponent implements OnInit {
  details: UserDetails;


  ingestion=false;
  wrangler=false;
  reporting=false;
  workflow=false;
  metadata=false;
  marketplace=false;


  constructor(public auth: AuthenticationService,private router : Router){}

  ngOnInit(): void {
    if(localStorage.getItem("usertoken") == null){
       alert('Please login First')
      this.router.navigateByUrl('')
  }
    this.auth.profile().subscribe(
      user => {
          this.details =user
          if(user.Name == 'sheetal')
          {
            this.ingestion=true;
            
            
          }

        else if(user.Name == 'Smita Maity')
          {
            this.wrangler=true;
            this.ingestion=true; 
          }

        else if(user.Name == 'Mrityunjoy Laha')
        {
          this.ingestion=true;
          this.wrangler=true;
          this.reporting=true;
          this.workflow=true;
          this.metadata=true;
          this.marketplace=true;
        }
      },
      err => {
          console.error(err)
      }
  )
}
  }


